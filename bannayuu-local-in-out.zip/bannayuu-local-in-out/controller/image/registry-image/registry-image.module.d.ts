export declare class RegistryImageModule {
}
