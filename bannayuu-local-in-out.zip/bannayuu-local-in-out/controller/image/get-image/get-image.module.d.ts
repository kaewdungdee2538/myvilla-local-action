import { MiddlewareConsumer } from '@nestjs/common';
export declare class GetImageModule {
    configure(consumer: MiddlewareConsumer): void;
}
