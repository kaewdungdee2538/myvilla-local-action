import { MiddlewareConsumer } from '@nestjs/common';
export declare class LPRBCheckOutModule {
    configure(consumer: MiddlewareConsumer): void;
}
