export declare class LptBSaveOutModule {
}
