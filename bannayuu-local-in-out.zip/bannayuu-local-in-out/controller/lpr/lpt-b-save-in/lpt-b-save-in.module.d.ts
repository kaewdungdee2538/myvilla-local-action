export declare class LptBSaveInModule {
}
