export declare class HttpCalculateController {
}
