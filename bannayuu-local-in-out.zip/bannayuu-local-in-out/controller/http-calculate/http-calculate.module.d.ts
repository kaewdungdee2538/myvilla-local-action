export declare class HttpCalculateModule {
}
