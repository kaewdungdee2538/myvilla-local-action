export declare class ActionInModule {
}
