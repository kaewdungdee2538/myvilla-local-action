import { MiddlewareConsumer } from '@nestjs/common';
export declare class VisitorGetPriceofcardlossModule {
    configure(consumer: MiddlewareConsumer): void;
}
