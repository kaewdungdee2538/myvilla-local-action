export declare class VisitorSaveCardlossModule {
}
