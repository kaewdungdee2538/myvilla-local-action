import { MiddlewareConsumer } from '@nestjs/common';
export declare class CheckCardModule {
    configure(consumer: MiddlewareConsumer): void;
}
