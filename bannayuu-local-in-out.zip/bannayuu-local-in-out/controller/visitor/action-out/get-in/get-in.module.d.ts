import { MiddlewareConsumer } from '@nestjs/common';
export declare class GetInModule {
    configure(consumer: MiddlewareConsumer): void;
}
