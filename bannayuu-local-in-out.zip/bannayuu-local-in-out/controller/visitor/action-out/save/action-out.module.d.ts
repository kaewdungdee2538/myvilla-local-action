export declare class ActionOutSaveModule {
}
