import { MiddlewareConsumer } from '@nestjs/common';
export declare class GetCartypeModule {
    configure(consumer: MiddlewareConsumer): void;
}
