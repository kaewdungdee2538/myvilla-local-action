import { MiddlewareConsumer } from '@nestjs/common';
export declare class GetSlipModule {
    configure(consumer: MiddlewareConsumer): void;
}
