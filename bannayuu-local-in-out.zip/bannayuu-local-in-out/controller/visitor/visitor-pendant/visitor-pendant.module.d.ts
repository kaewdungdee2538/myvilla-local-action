import { MiddlewareConsumer } from '@nestjs/common';
export declare class VisitorPendantModule {
    configure(consumer: MiddlewareConsumer): void;
}
