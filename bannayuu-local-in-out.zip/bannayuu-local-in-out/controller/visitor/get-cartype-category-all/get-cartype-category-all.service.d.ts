import { dbConnection } from 'src/pg_database/pg.database';
import { ErrMessageUtilsTH } from 'src/utils/err_message_th.utils';
export declare class GetCartypeCategoryAllService {
    private readonly dbconnecttion;
    private readonly errMessageUtilsTh;
    constructor(dbconnecttion: dbConnection, errMessageUtilsTh: ErrMessageUtilsTH);
    getCartypeCategoryAll(body: any): Promise<void>;
    getCartypeCategoryInfoAll(body: any): Promise<void>;
}
