import { MiddlewareConsumer } from '@nestjs/common';
export declare class GetHomeModule {
    configure(consumer: MiddlewareConsumer): void;
}
