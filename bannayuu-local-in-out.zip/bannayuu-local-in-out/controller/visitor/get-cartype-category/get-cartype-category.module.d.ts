import { MiddlewareConsumer } from '@nestjs/common';
export declare class GetCartypeCategoryModule {
    configure(consumer: MiddlewareConsumer): void;
}
