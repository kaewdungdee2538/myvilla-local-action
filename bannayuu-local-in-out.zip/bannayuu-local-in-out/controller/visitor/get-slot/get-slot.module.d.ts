import { MiddlewareConsumer } from '@nestjs/common';
export declare class GetSlotModule {
    configure(consumer: MiddlewareConsumer): void;
}
