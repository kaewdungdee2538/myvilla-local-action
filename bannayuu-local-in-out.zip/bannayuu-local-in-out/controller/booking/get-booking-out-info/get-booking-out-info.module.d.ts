import { MiddlewareConsumer } from '@nestjs/common';
export declare class GetBookingOutInfoModule {
    configure(consumer: MiddlewareConsumer): void;
}
