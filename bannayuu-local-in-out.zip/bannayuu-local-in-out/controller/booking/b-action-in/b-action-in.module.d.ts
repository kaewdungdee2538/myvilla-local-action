export declare class BActionInModule {
}
