export declare class BActionOutModule {
}
