export declare class CalTimediffModule {
}
