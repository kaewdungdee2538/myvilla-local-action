export declare class CalTimediffService {
    calTimeDiffFormDateStartToDateEnd(dateStart: string, dateEnd: string): Promise<number>;
    convertTimeDiffToText(intervalInput: number): string;
}
