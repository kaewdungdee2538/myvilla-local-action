export declare class CalTimediffController {
}
