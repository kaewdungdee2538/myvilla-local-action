export declare class ResetVisitorModule {
}
