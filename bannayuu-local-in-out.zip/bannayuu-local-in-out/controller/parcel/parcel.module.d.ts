export declare class ParcelModule {
}
