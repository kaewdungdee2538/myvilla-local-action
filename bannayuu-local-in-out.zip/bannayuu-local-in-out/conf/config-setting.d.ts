export declare const configfile: {
    HOST: string;
    DATABASE: string;
    DATABASE_PORT: number;
    PORT_API: string;
    PATHSAVEIMAGE: string;
    PATHPACELSAVEIMAGE: string;
    PATHFOLDERSTATIC: string;
    MYCOMPANY_ID: string;
    IMAGE_SIZE: number;
    URL_CALCULATE: string;
    HOST_LINE_NOTIFICATION: string;
    PATH_LINE_ACTION_IN_NOTIFICATION: string;
    HOST_LINE_NOTIFICATION_BOARDCAST: string;
    PATH_LINE_ACTION_IN_NOTIFICATION_BOARDCAST: string;
};
