"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.configfile = void 0;
exports.configfile = {
    HOST: '192.168.81.135',
    DATABASE: 'demo_bannayuu_db',
    DATABASE_PORT: 50005,
    PORT_API: '36005',
    PATHSAVEIMAGE: '/home/ubuntu/banayuu_images/visitor',
    PATHPACELSAVEIMAGE: '/home/ubuntu/banayuu_images/webmanagement',
    PATHFOLDERSTATIC: '/home/ubuntu/banayuu_images/visitor',
    MYCOMPANY_ID: '1',
    IMAGE_SIZE: 10,
    URL_CALCULATE: 'http://localhost:36006/api/bannayuu/calculate/cal-all',
    HOST_LINE_NOTIFICATION: 'http://localhost:38502/apicross/webhook',
    PATH_LINE_ACTION_IN_NOTIFICATION: '/push_noti_home_line',
    HOST_LINE_NOTIFICATION_BOARDCAST: 'http://localhost:38501/line_notify',
    PATH_LINE_ACTION_IN_NOTIFICATION_BOARDCAST: '/push_notify_home_line',
};
//# sourceMappingURL=config-setting.js.map