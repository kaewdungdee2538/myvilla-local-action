export declare class SlotManageModule {
}
