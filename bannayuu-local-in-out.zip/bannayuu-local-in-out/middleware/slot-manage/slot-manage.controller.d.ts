export declare class SlotManageController {
}
