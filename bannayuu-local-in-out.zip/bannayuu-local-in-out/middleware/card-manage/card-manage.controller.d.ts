export declare class CardManageController {
}
