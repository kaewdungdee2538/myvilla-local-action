export declare class CardManageModule {
}
