export declare const imageFileFilter: (req: any, file: any, callback: any) => any;
export declare const editFileName: (req: any, file: any, callback: any) => any;
export declare const getCurrentDatePathFileSave: (req: any, file: any, callback: any) => void;
export declare const getCurrentDatePathFileForPacelSave: (req: any, file: any, callback: any) => void;
