import { MiddlewareConsumer } from '@nestjs/common';
export declare class GetVisitorOutHistoryModule {
    configure(consumer: MiddlewareConsumer): void;
}
